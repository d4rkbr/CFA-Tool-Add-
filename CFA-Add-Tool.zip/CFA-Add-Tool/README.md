# CFA-Add-Tool
Quick Python tool to help add cards to Cardfight Area.
(Compiled .exe can found be in releases)

What it actually does:
  - Modifies line 3 of *[Directory]/Text/NoUse.txt*, increasing the number by 1
  
  - Adds .jpg copies of [Image]:
    - 300 x 437 to *[Directory]/Cardsprite/n[New Number].jpg*
    - 60 x 87 to *[Directory]/CardSpriteMini/n[New Number].jpg*
    - 75 x 109 *[Directory]/CardSpriteMini2/n[New Number].jpg*
    
  - Appends the given card info to *[Directory given]/Text/[Clan].txt*

To do:
  - Clean codebase
  - Add Quick Shield option
  - Add Premium legality
